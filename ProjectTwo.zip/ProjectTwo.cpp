//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Justin Leger
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Project Two
//============================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string> // atoi
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

const unsigned int DEFAULT_SIZE = 179;

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Course {
    string courseId; // unique identifier
    string title;
    //vector<string> preReqList;
    string preReq1;
    string preReq2;

    //string fund;
    //double amount;
    Course() {
        //amount = 0.0;
    }
};

//============================================================================
// Hash Table class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a hash table with chaining.
 */
class HashTable {

private:
    // Define structures to hold bids
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        // default constructor
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }

        // initialize with a bid
        Node(Course aCourse) : Node() {
            course = aCourse;
        }

        // initialize with a bid and a key
        Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
            key = aKey;
        }
    };

    vector<Node> nodes;

    unsigned int tableSize = DEFAULT_SIZE;

    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned int size);
    virtual ~HashTable();
    void Insert(Course course);
    void PrintAll();
    void Remove(string courseId);
    Course Search(string courseId);
    size_t Size();
};

/**
 * Default constructor
 */
HashTable::HashTable() {
    // FIXME (1): Initialize the structures used to hold bids

    // Initalize node structure by resizing tableSize
    nodes.resize(tableSize);
}

/**
 * Constructor for specifying size of the table
 * Use to improve efficiency of hashing algorithm
 * by reducing collisions without wasting memory.
 */
HashTable::HashTable(unsigned int size) {
    // invoke local tableSize to size with this->
    this->tableSize = size;
    // resize nodes size
    nodes.resize(size);
}

/**
 * Destructor
 */
HashTable::~HashTable() {
    // FIXME (2): Implement logic to free storage when class is destroyed

    // erase nodes beginning
    nodes.erase(nodes.begin());
}

/**
 * Calculate the hash value of a given key.
 * Note that key is specifically defined as
 * unsigned int to prevent undefined results
 * of a negative list index.
 *
 * @param key The key to hash
 * @return The calculated hash
 */
unsigned int HashTable::hash(int key) {
    // FIXME (3): Implement logic to calculate a hash value
    // return key tableSize
    return key % tableSize;
}

/**
 * Insert a bid
 *
 * @param bid The bid to insert
 */

void HashTable::Insert(Course course) {
    
    // FIXME (4): Implement logic to insert a bid
    // create the key for the given bid
    unsigned int key = hash(stoi(course.courseId));
    // retrieve node using key
    Node* prev = &(nodes.at(key));
    // if no entry found for the key
    if (prev == nullptr) {
        // assign this node to the key position
        Node* next = new Node(course, key);
        nodes.insert(nodes.begin() + key, (*next));
    }

    // else if node is not used
    else if (nodes.at(key).key == UINT_MAX) {
        // assigning old node key to UNIT_MAX, set to key, set old node to bid and old node next to null pointer
        prev->key = key;
        prev->course = course;
        prev->next = nullptr;
    }
    // else find the next open node
    else {
        while (prev->next != nullptr) {
            // add new newNode to end
            prev = prev->next;
        }
    }
    
}

/**
 * Print all courses
 */
void HashTable::PrintAll() {
    // FIXME (5): Implement logic to print all bids
    // for node begin to end iterate
    for (int i = 0; i < nodes.size(); i++) {
        Node* node = &nodes.at(i);
        //   if key not equal to UINT_MAcks
        if (nodes[i].key != UINT_MAX) {
            // output key, bidID, title, amount and fund
            cout << nodes[i].key << " | " <<
                nodes[i].course.courseId << " | " <<
                nodes[i].course.title << " | " << endl;
            // node is equal to next iter
            // while node not equal to nullptr
            while (node->next != nullptr) {
                // output key, bidID, title, amount and fund
                cout << nodes[i].key << " | " <<
                    nodes[i].course.courseId << " | " <<
                    nodes[i].course.title << " | " << endl;
                // node is equal to next node
                node = node->next;
            }
        }
    }
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadCourses(string csvPath, HashTable* hashTable) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Course course;
            course.courseId = file[i][0];
            course.title = file[i][1];
            course.preReq1 = file[i][2];
            course.preReq2 = file[i][3];

            // push this bid to the end
            hashTable->Insert(course);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, courseKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        courseKey = "98223";
        break;
    case 3:
        csvPath = argv[1];
        courseKey = argv[2];
        break;
    default:
        //cout << "Please provide the file name containing the course data" << endl;
        //cin >> filePath;
        csvPath = "CS 300 ABCU_Advising_Program_Input.csv";
        courseKey = "98223";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a hash table to hold all the bids
    HashTable* courseTable;

    Course course;
    courseTable = new HashTable();

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Print Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:

            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadCourses(csvPath, courseTable);

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            courseTable->PrintAll();
            break;

        case 3:
            ticks = clock();

            //course = courseTable->Search(courseKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!course.courseId.empty()) {
                //displayCourse(course);
            }
            else {
                cout << "Bid Id " << courseKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;
        }
    }
    cout << "Good bye." << endl;

    return 0;
}
